package com.yulan.wemedia.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yulan.model.wemedia.pojos.WmChannel;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface WmChannelMapper extends BaseMapper<WmChannel> {
}