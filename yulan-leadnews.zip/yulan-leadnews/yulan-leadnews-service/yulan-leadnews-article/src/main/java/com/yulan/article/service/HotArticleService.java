package com.yulan.article.service;

public interface HotArticleService {

    /**
     * 计算热点文章
     */
    public void computeHotArticle();
}
