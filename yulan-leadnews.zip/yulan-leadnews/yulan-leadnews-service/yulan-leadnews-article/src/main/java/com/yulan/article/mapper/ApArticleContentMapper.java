package com.yulan.article.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yulan.model.article.pojos.ApArticleContent;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ApArticleContentMapper extends BaseMapper<ApArticleContent> {

}
